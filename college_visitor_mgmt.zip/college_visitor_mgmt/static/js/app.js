document.addEventListener("DOMContentLoaded", () => {
  console.log("CVMS app loaded");
});
